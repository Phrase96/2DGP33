import game_framework
import score_state

game_framework.run(score_state)